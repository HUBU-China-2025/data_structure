// jump to the page of payment
const gotopay=document.getElementById('gotopay')

gotopay.addEventListener('click',function(){
    window.location.href='pay.html'
})

//Get add for click
const buy1=document.getElementById('buy1')
const buy2=document.getElementById('buy2')
const buy3=document.getElementById('buy3')
const buy4=document.getElementById('buy4')

//Get the elements for delete
const buy01=document.getElementById('101')
const buy02=document.getElementById('201')
const buy03=document.getElementById('301')
const buy04=document.getElementById('401')

//get each book
const buybox1=document.getElementById('1')
const buybox2=document.getElementById('2')
const buybox3=document.getElementById('3')
const buybox4=document.getElementById('4')

const contents = document.getElementsByClassName('trolley_content');  
let list = localStorage.getItem('list');  
let listArr = list ? JSON.parse(list) : [];  
  
// Make sure there are at least one content elememt  
if (contents.length > 0) {  
    const content = contents[0];  
  
    listArr.forEach((element, index) => {  
        // Create a new div 
		const dic = element;
        const div = document.createElement('div');  
        div.className = 'tro tro1'; // get the ID we want  
        div.innerHTML = `  
            <img src="${dic.img}" class="tropic" />  
            <span class="title">${dic.title}</span>  
            <div>  
                <span>Number</span>  
                <span>  
                    <select>  
                        <option>1</option>  
                        <option>2</option>  
                        <option>3</option>  
                        <option>4</option>  
                        <option>5</option>  
                        <option>6</option>  
                        <option>7</option>  
                        <option>8</option>  
                        <option>9</option>  
                        <option>10</option>  
                    </select>  
                </span>  
            </div>  
            <span class='del'>Delete</span>  <br>
        `;  
        // get the button for delete
        const del = div.getElementsByClassName('del');
        del[0].addEventListener('click', () => {
            div.remove(); //Delete this div from the DOM  
            // update the way for localStorage
            listArr.splice(index, 1);
            localStorage.setItem('list', JSON.stringify(listArr));
        })
  
        // add new div to the content  
        content.appendChild(div);  
    });  
} else {  
    console.log('Did not find an element which has the class of "trolley_content" ');  
}



//add and delete
buy1.addEventListener('click', function(){
	buybox1.style.display='block'
})

buy2.addEventListener('click', function(){
	buybox2.style.display='block'
})

buy3.addEventListener('click', function(){
	buybox3.style.display='block'
})

buy4.addEventListener('click', function(){
	buybox4.style.display='block'
})

buy01.addEventListener('click',function(){
	buybox1.style.display='none'
})

buy02.addEventListener('click',function(){
	buybox2.style.display='none'
})

buy03.addEventListener('click',function(){
	buybox3.style.display='none'
})

buy04.addEventListener('click',function(){
	buybox4.style.display='none'
})

