// Get a locally stored number
const successnumber=localStorage.getItem('success')
// Get the last four numbers
const fournumber=String(successnumber).slice(-4)
// Get id
const changenumber=document.getElementById('suc1')
changenumber.innerHTML='**** **** **** '+fournumber
