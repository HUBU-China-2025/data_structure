

// detailed introduction
// get the picture
const introxiyou1=document.querySelector('.introxiyoupic01')
const introxiyou2=document.querySelector('.introxiyoupic02')
const introxiyou3=document.querySelector('.introxiyoupic03')
//Change the content
const introxiyou4=document.querySelector('.introcontent1')
const introxiyou5=document.querySelector('.introcontent2')
const introxiyou6=document.querySelector('.introcontent3')
//Change the background
// const introxiyouback=document.querySelector('.introback')

introxiyou1.addEventListener('click',function(){
	introxiyou4.style.display='block'
	introxiyou5.style.display='none'
	introxiyou6.style.display='none'
	// Change the picture after click
	// introxiyou1.src='../picture/xiyoutouxiang01-after.png'
	introxiyou1.style.scale='115%'
	introxiyou2.style.scale='100%'
	introxiyou3.style.scale='100%'
	// introxiyou1.style.translate='150% -100%'
	// introxiyouback.style.animation='introback1 5s ease-in-out infinite'
})
introxiyou2.addEventListener('click',function(){
	introxiyou4.style.display='none'
	introxiyou5.style.display='block'
	introxiyou6.style.display='none'
	introxiyou1.style.scale='100%'
	introxiyou2.style.scale='115%'
	introxiyou3.style.scale='100%'
	// introxiyouback.style.animation='introback2 5s ease-in-out infinite'
})
introxiyou3.addEventListener('click',function(){
	introxiyou4.style.display='none'
	introxiyou5.style.display='none'
	introxiyou6.style.display='block'
	introxiyou1.style.scale='100%'
	introxiyou2.style.scale='100%'
	introxiyou3.style.scale='115%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})

// detailed introduction
// get the picture
const introhonglou1=document.querySelector('.introhongloupic01')
const introhonglou2=document.querySelector('.introhongloupic02')
const introhonglou3=document.querySelector('.introhongloupic03')
//Change the content
const introhonglou4=document.querySelector('.introcontent4')
const introhonglou5=document.querySelector('.introcontent5')
const introhonglou6=document.querySelector('.introcontent6')
//Change the background
introhonglou1.addEventListener('click',function(){
	introhonglou4.style.display='block'
	introhonglou5.style.display='none'
	introhonglou6.style.display='none'
	introhonglou1.style.scale='115%'
	introhonglou2.style.scale='100%'
	introhonglou3.style.scale='100%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})
introhonglou2.addEventListener('click',function(){
	introhonglou4.style.display='none'
	introhonglou5.style.display='block'
	introhonglou6.style.display='none'
	introhonglou1.style.scale='100%'
	introhonglou2.style.scale='115%'
	introhonglou3.style.scale='100%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})
introhonglou3.addEventListener('click',function(){
	introhonglou4.style.display='none'
	introhonglou5.style.display='none'
	introhonglou6.style.display='block'
	introhonglou1.style.scale='100%'
	introhonglou2.style.scale='100%'
	introhonglou3.style.scale='115%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})

// detailed introduction
// get the picture
const introshuihu1=document.querySelector('.introshuihupic01')
const introshuihu2=document.querySelector('.introshuihupic02')
const introshuihu3=document.querySelector('.introshuihupic03')
//Change the content
const introshuihu4=document.querySelector('.introcontent7')
const introshuihu5=document.querySelector('.introcontent8')
const introshuihu6=document.querySelector('.introcontent9')
//Change the background
introshuihu1.addEventListener('click',function(){
	introshuihu4.style.display='block'
	introshuihu5.style.display='none'
	introshuihu6.style.display='none'
	introshuihu1.style.scale='115%'
	introshuihu2.style.scale='100%'
	introshuihu3.style.scale='100%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})
introshuihu2.addEventListener('click',function(){
	introshuihu4.style.display='none'
	introshuihu5.style.display='block'
	introshuihu6.style.display='none'
	introshuihu1.style.scale='100%'
	introshuihu2.style.scale='115%'
	introshuihu3.style.scale='100%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})
introshuihu3.addEventListener('click',function(){
	introshuihu4.style.display='none'
	introshuihu5.style.display='none'
	introshuihu6.style.display='block'
	introshuihu1.style.scale='100%'
	introshuihu2.style.scale='100%'
	introshuihu3.style.scale='115%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})

// detailed introduction
// get the picture
const introsanguo1=document.querySelector('.introsanguopic01')
const introsanguo2=document.querySelector('.introsanguopic02')
const introsanguo3=document.querySelector('.introsanguopic03')
//Change the content
const introsanguo4=document.querySelector('.introcontent10')
const introsanguo5=document.querySelector('.introcontent11')
const introsanguo6=document.querySelector('.introcontent12')
//Change the background
introsanguo1.addEventListener('click',function(){
	introsanguo4.style.display='block'
	introsanguo5.style.display='none'
	introsanguo6.style.display='none'
	introsanguo1.style.scale='115%'
	introsanguo2.style.scale='100%'
	introsanguo3.style.scale='100%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})
introsanguo2.addEventListener('click',function(){
	introsanguo4.style.display='none'
	introsanguo5.style.display='block'
	introsanguo6.style.display='none'
	introsanguo1.style.scale='100%'
	introsanguo2.style.scale='115%'
	introsanguo3.style.scale='100%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})
introsanguo3.addEventListener('click',function(){
	introsanguo4.style.display='none'
	introsanguo5.style.display='none'
	introsanguo6.style.display='block'
	introsanguo1.style.scale='100%'
	introsanguo2.style.scale='100%'
	introsanguo3.style.scale='115%'
	// introxiyouback.style.animation='introback3 5s ease-in-out infinite'
})

//get the add click
const buy1=document.getElementById('buy1')
const buy2=document.getElementById('buy2')
const buy3=document.getElementById('buy3')
const buy4=document.getElementById('buy4')
const list = localStorage.getItem('list')
let listArr = list ? JSON.parse(list) : []

//add and delete
buy1.addEventListener('click', function(){
	let dic = {"title": "The Journey to the West",  "price": 20, "img": "picture/xiyou.jpg"}
	listArr.push(dic)
	localStorage.setItem('list', JSON.stringify(listArr))
})

buy2.addEventListener('click', function(){
	let dic = {"title": "A Dream of Red Mansions", "price": 20, "img": "picture/honglou.jpg"}
	listArr.push(dic)
	localStorage.setItem('list', JSON.stringify(listArr))
})

buy3.addEventListener('click', function(){
	let dic = {"title": "Water Margin", "price": 20, "img": "picture/shuihu.jpg"}
	listArr.push(dic)
	localStorage.setItem('list', JSON.stringify(listArr))
})

buy4.addEventListener('click', function(){
	let dic = {"title": "Romance of the Three KingdomsThe Three Kingdoms Era", "price": 20, "img": "picture/sanguo.jpg"}
	listArr.push(dic)
	localStorage.setItem('list', JSON.stringify(listArr))
})

// get the header on the phone
const header2=document.getElementById('header2pic')
//get the selector
const headershow=document.querySelector('.headernav')

header2.addEventListener('click',function(){
	if(headershow.style.display==='block'){
		headershow.style.display='none'
	}
	else {
		headershow.style.display='block'
	}
})