// Click for changing the way to pay
//Get the box above the pictures
const visa = document.querySelector('.paypic1')
const wechat = document.querySelector('.paypic2')
const alipay = document.querySelector('.paypic3')
// Change the box below
const visa1 = document.querySelector('.paybox01')
const wechat1 = document.querySelector('.paybox02')
const alipay1 = document.querySelector('.paybox03')
// Click visa
visa.addEventListener('click', function () {
	visa1.style.display = 'block'
	wechat1.style.display = 'none'
	alipay1.style.display = 'none'
})
// Click wechat
wechat.addEventListener('click', function () {
	visa1.style.display = 'none'
	wechat1.style.display = 'block'
	alipay1.style.display = 'none'
})
// Click alipay
alipay.addEventListener('click', function () {
	visa1.style.display = 'none'
	wechat1.style.display = 'none'
	alipay1.style.display = 'block'
})


// Get the key of submit
const sub = document.getElementById('sub')
//Get a card number and verify it
const cardnumber = document.getElementById('cardnumber')
//Use regular expressions to determine the first digit of a card number
const numbertest = /^(51|52|53|54|55)\d{14}$/
//Get the inspection element
let checknumber = 'false'
let checkyear = 'false'
let checkmonth = 'false'
let checkpass = 'false'

//Get the month and the years
let year = document.getElementById('year').value
let month = document.getElementById('month').value
sub.addEventListener('click', function () {
	year = document.getElementById('year').value
	month = document.getElementById('month').value
	if (cardnumber.value.length === 16 && numbertest.test(cardnumber.value)) {
		checknumber = 'true'
	} else {
		checknumber = 'false'
		alert('Please input the correct card number')
		return
	}
	if (year > 2024) {
		checkyear = 'true'
		checkmonth = 'true'
	} else if (year == 2024) {
		if (month >= 11) {
			checkyear = 'true'
			checkmonth = 'true'
		} else {
			checkmonth = 'false'
			checkyear = 'true'
		alert('Please select the correct month')
		return
		}
	} else {
		checkmonth = 'false'
		checkyear = 'false'
		alert('Please select the correct year')
		return
	}
	
	//Get the password and varify it
	const password = document.getElementById('password').value
	if (!isNaN(password) && (password.length == 3 || password.length == 4)) {
		checkpass = 'true'
	} else {
		checkpass = 'false'
		alert('Please input the correct password ')
		return
	}
	submit();
})

function submit() {


	//The conditions are complete, start to varify it
	if (checkmonth == 'true' && checkyear == 'true' && checknumber == 'true' && checkpass == 'true') {
		const dataform = {
			"master_card": cardnumber.value,
			"exp_year": year,
			"exp_month": month,
			"cvv_code": password.value
		}
		//Send to the server and verify
		fetch('https://mudfoot.doc.stu.mmu.ac.uk/node/api/creditcard', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(dataform)
			})

			.then(response => {
				// if (!response.ok) {
				// 	throw new Error('Network response was not ok');
				// }
				return response.json();
			})
			.then(data => {
				console.log(data);
				if (data.message === "Thank you for your payment") {
					localStorage.setItem('success', cardnumber.value )
					window.open('success.html')
				} else {
					alert('Payment failed. Please try again.');
				}
			});
			// .catch(error => {
			// 	alert('There was a problem with your payment: ' + error.message)
			// 		// location.href = 'index.html'
			// });
	}
}